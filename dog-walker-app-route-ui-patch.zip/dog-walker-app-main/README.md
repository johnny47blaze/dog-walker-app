# Dog Walk Tracker

Android dog-walking weather, route planning, and walk tracking app.

## Route planner update

- Choose a 0.25–2.50 mile walking loop in 0.25-mile steps.
- Auto-loop requests pedestrian routes only (no driving-router fallback).
- Calibrates against the *routed* length for up to four attempts.
- Rejects generated loops that miss the target by more than 15%, with a visible explanation.
- Preserves an existing route when automatic generation fails.
- Route planning panel now clearly separates target mileage, current route mileage, and status.

**Important:** This source bundle does not include a Gradle wrapper, so it has not been built or tested on an Android device in this environment. Public routing services can be unavailable or rate-limited. The route planner must be tested on real street networks before release.
